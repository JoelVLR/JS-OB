//calcular factorial de 10 utilizando un bucle while
let i=0
let max=10
let r=1
while(i<max){
    i++;
    r*=i
    console.log(r);
}
