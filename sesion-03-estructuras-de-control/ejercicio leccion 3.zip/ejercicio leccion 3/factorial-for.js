//factorial de 10 con un soo bucle for
let r =1;

for (i=1;i<=10;i++){
    r*=i;
    console.log(r);
}
