let i=0
let r=1

while(true){
    i++
    r*=i
    console.log(r)
    if(i===10){ 
        break
    }

}
